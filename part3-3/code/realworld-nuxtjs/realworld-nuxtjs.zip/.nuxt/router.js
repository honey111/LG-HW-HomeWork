import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _08eec91e = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _6607afd3 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _5b2692f5 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _04f47a35 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _2adadd17 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _05c0213e = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _288284fc = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _08eec91e,
    children: [{
      path: "",
      component: _6607afd3,
      name: "home"
    }, {
      path: "/login",
      component: _5b2692f5,
      name: "login"
    }, {
      path: "/register",
      component: _5b2692f5,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _04f47a35,
      name: "profile"
    }, {
      path: "/settings",
      component: _2adadd17,
      name: "settings"
    }, {
      path: "/editor",
      component: _05c0213e,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _288284fc,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
