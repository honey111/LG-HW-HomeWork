import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _48345fa7 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _1da3549c = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _d200f168 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _a33c9668 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _a1d61540 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _3c6585ea = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _d5a80fce = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _48345fa7,
    children: [{
      path: "",
      component: _1da3549c,
      name: "home"
    }, {
      path: "/login",
      component: _d200f168,
      name: "login"
    }, {
      path: "/register",
      component: _d200f168,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _a33c9668,
      name: "profile"
    }, {
      path: "/settings",
      component: _a1d61540,
      name: "settings"
    }, {
      path: "/editor",
      component: _3c6585ea,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _d5a80fce,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
